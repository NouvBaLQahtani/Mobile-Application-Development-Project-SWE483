package com.example.academate.ui.home;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.academate.R;
import com.example.academate.database.DutyRepository;
import com.example.academate.model.Duty;
import com.example.academate.ui.task.EventDetailAdapter;
import com.example.academate.utils.CalendarCustomView;
import com.example.academate.utils.DateUtils;
import com.example.academate.utils.EventObjects;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

public class CalendarActivity extends AppCompatActivity {

    Date start, end;
    LinearLayout layoutCalender;
    View custom_view;
    Date initialDate, lastDate;

    private List<Duty> dutyList;
    private DutyRepository dutyRepository;
    private Dialog dialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        dutyRepository = new DutyRepository(getApplicationContext());
        dutyList = new ArrayList<>();
        dutyList.addAll(dutyRepository.getAllDuties().getValue());
        setInitializations();
        setCalenderView();
    }

    private void setInitializations() {
        custom_view = (View) findViewById(R.id.custom_view);
        layoutCalender = (LinearLayout) findViewById(R.id.layoutCalender);
    }

    public void setCalenderView() {

        //Custom Events
        List<EventObjects> mEvents = new ArrayList<>();
        for (int i = 0; i < dutyList.size(); i++) {
            mEvents.add(new EventObjects(i, "Event: " + dutyList.get(i).getTitle() +"\nTime: "+dutyList.get(i).getTime(), dutyList.get(i).getDateAsDate()));
        }

        ViewGroup parent = (ViewGroup) custom_view.getParent();
        parent.removeView(custom_view);
        layoutCalender.removeAllViews();
        layoutCalender.setOrientation(LinearLayout.VERTICAL);

        final CalendarCustomView calendarCustomView = new CalendarCustomView(this, mEvents);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.MATCH_PARENT);
        calendarCustomView.setLayoutParams(layoutParams);
        layoutCalender.addView(calendarCustomView);

        calendarCustomView.calendarGridView.setOnItemClickListener((adapterView, view, i, l) -> {
            if (adapterView.getAdapter().getView((int) l, null, null).getAlpha() == 0.4f) {
                Log.d("hello", "hello");
            } else {
                Calendar today = Calendar.getInstance();
                today.setTime(new Date());

                Calendar tapedDay = Calendar.getInstance();
                tapedDay.setTime((Date) adapterView.getAdapter().getItem((int) l));
                boolean sameDay = tapedDay.get(Calendar.YEAR) == tapedDay.get(Calendar.YEAR) &&
                        today.get(Calendar.DAY_OF_YEAR) == tapedDay.get(Calendar.DAY_OF_YEAR);
           /*     if (today.after(tapedDay) && !sameDay) {
                    Toast.makeText(CalendarActivity.this, "No event added yet.", Toast.LENGTH_LONG).show();
                }
                else {*/
                 /*   if (initialDate == null && lastDate == null) {
                        initialDate = lastDate = (Date) adapterView.getAdapter().getItem((int) l);
                    } else {
                        initialDate = lastDate;
                        lastDate = (Date) adapterView.getAdapter().getItem((int) l);
                    }
                    if (initialDate != null && lastDate != null) {
                        calendarCustomView.setRangesOfDate(makeDateRanges());
                    }*/
                    try {
                        List<EventObjects> FilteredList = new ArrayList<>();

                        for (int iff = 0; iff < mEvents.size(); iff++) {
                            String formattedInitialDate = DateUtils.getFormattedDate(tapedDay.getTime().toString(),"dd, MMMM yyyy");
                            String formattedEventDate = DateUtils.getFormattedDate(mEvents.get(iff).getDate().toString(),"dd, MMMM yyyy");

                            if (formattedEventDate.equals(formattedInitialDate)) {
                                FilteredList.add(mEvents.get(iff));
                            }
                        }
                        if(!FilteredList.isEmpty()) {
                            showEventsDetail(FilteredList);
                        }
                        else
                        {
                            Toast.makeText(this, "No Duty Added ", Toast.LENGTH_SHORT).show();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
              //  }
            }


        });


    }

    private void showEventsDetail(List<EventObjects> mEvents) {
        dialog = new Dialog(this);
        dialog.setContentView(R.layout.event_dialog);
        dialog.setCancelable(true);
        getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        getWindow().setGravity(Gravity.BOTTOM);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        TextView textViewDate = dialog.findViewById(R.id.tvDate);
        RecyclerView eventsRecycler = dialog.findViewById(R.id.eventRecycler);
        textViewDate.setText(DateUtils.getFormattedDate(mEvents.get(0).getDate().toString(),"MMM YYYY"));
        EventDetailAdapter eventDetailAdapter = new EventDetailAdapter(mEvents);
        eventsRecycler.setAdapter(eventDetailAdapter);
        eventsRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        dialog.show();
    }

    public List<EventObjects> makeDateRanges() {
        if (lastDate.after(initialDate)) {
            start = initialDate;
            end = lastDate;
        } else {
            start = lastDate;
            end = initialDate;
        }
        List<EventObjects> eventObjectses = new ArrayList<>();
        GregorianCalendar gcal = new GregorianCalendar();
        gcal.setTime(start);

        while (!gcal.getTime().after(end)) {
            Date d = gcal.getTime();
            EventObjects eventObject = new EventObjects("", d);
            eventObject.setColor(getResources().getColor(R.color.colorAccent));
            eventObjectses.add(eventObject);
            gcal.add(Calendar.DATE, 1);
        }
        return eventObjectses;
    }


}
