package com.example.academate.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateUtils {

    // Define the input date format for parsing
    private static final SimpleDateFormat inputFormat = new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US);

    // Define the output date format for formatting

    public static String getFormattedDate(String dateString,String outputFormat) {
        try {
            SimpleDateFormat output = new SimpleDateFormat(outputFormat, Locale.US);

            // Parse the input string to a Date object
            Date date = inputFormat.parse(dateString);

            // Format the Date object to get the formatted date string
            return output.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return null; // Return null in case of parsing error
        }
    }
}
