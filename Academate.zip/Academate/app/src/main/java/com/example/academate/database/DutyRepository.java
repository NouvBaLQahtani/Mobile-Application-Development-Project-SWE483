package com.example.academate.database;

import android.content.Context;

import androidx.lifecycle.LiveData;

import com.example.academate.model.Duty;

import java.util.List;

public class DutyRepository {
    private DutyDao dutyDao;
    private LiveData<List<Duty>> allDuties;
    private LiveData<List<Duty>> upcomingDuties;
    private DutyDbHelper dbHelper;

    public DutyRepository(Context context) {
        dbHelper = new DutyDbHelper(context);
        dutyDao = new DutyDao(dbHelper);
        allDuties = dutyDao.getAllDuties();
        upcomingDuties = dutyDao.getUpcomingDuties();
    }


    public LiveData<List<Duty>> getAllDuties() {
        return allDuties;
    }

    public LiveData<List<Duty>> getUpcomingDuties() {
        return upcomingDuties;
    }

    public String insertTask(Duty duty) {
        if (!dutyDao.isDuplicateDateTime(duty)) {
            dutyDao.insert(duty);
            return "Duty Added Successfully";
        } else {
            return "Error: Duplicate date and time. Please select a different date and time.";
        }
    }

    public String updateTask(Duty duty) {
        if (!dutyDao.isDuplicateDateTime(duty)) {
            dutyDao.update(duty);
            return "Duty Updated Successfully";
        } else {
            return "Error: Duplicate date and time. Please select a different date and time.";
        }
    }

    public void deleteTask(Duty duty) {
        dutyDao.delete(duty);
    }

    public void closeDatabase() {
        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}


