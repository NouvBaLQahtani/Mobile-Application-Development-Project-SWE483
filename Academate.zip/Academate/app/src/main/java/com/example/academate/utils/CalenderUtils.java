package com.example.academate.utils;

public interface CalenderUtils {
    public void nextMonth();
    public void previousMonths();
}
