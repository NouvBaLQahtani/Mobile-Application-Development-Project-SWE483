package com.example.academate.ui.home;

import android.Manifest;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.academate.R;
import com.example.academate.database.DutyRepository;
import com.example.academate.databinding.ActivityNotificationBinding;
import com.example.academate.model.Duty;
import com.example.academate.ui.task.ViewDutyDetail;
import com.google.android.material.textfield.TextInputEditText;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.Random;

public class NotificationActivity extends AppCompatActivity {
    private ActivityNotificationBinding binding;
    private DutyRepository dutyRepository;
    private Duty dutyIntent;
    private int selectedHour = 0;
    private int selectedMinute = 0;
    private Calendar calendar;

    public static final String EXTRA_TASK_TITLE = "extra_task_title";
    public static final String EXTRA_TASK_DESCRIPTION = "extra_task_description";
    public static final String TASK_NATURE_DESCRIPTION = "extra_task_nature";
    public static final String TASK_PRIORITY = "extra_task_priority";

    public static final String TASK_DATE = "extra_task_date";

    public static final String TASK_TIME = "extra_task_time";

    public static final String TASK_REMIND_BEFORE_TIME = "extra_task_remind_before";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityNotificationBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        dutyRepository = new DutyRepository(getApplicationContext());
        setupEventListeners();
        receiveData();

/*        binding.setTime.setOnClickListener(view -> {
            int random = new Random().nextInt();
            Log.d("Notification", "onCreate: " + random);
            requestRuntimePermissions(random);
        });*/
    }

    private void receiveData() {
        Intent intent = getIntent();
        if (intent.hasExtra("taskObject")) {
            dutyIntent = (Duty) intent.getSerializableExtra("taskObject");
            binding.edTaskTitle.setText(dutyIntent.getTitle());
            binding.edTaskDescription.setText(dutyIntent.getDescription());
            binding.edTaskDate.setText(dutyIntent.getDate());
            binding.edTaskTime.setText(dutyIntent.getTime());
            binding.btnSave.setText(R.string.confirm);
            binding.btnCancel.setVisibility(View.VISIBLE);
        }
    }

    private void setupEventListeners() {
        binding.btnSave.setOnClickListener(v -> {
            if (validation()) {
                saveTaskDetails();
            }
        });
        binding.btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveToHome();
            }
        });

        binding.edTaskDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int random = new Random().nextInt();
                Log.d("Notification", "onCreate: " + random);
                requestRuntimePermissions();
            }
        });

        binding.edTaskTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (calendar != null) {
                    showTimePicker(calendar);
                } else {
                    showToast("Select Date First");
                }

            }
        });


        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveToHome();
            }
        });

    }

    private void updateDate(Date date) {
        String dateFormat = "YYYY-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);
        binding.edTaskDate.setText(sdf.format(date));
    }

    private void updateTime() {
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        binding.edTaskTime.setText(timeFormat.format(calendar.getTime()));
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private String getString(Spinner editText) {
        return Objects.requireNonNull(editText.getSelectedItem()).toString();
    }

    private String getString(TextInputEditText editText) {
        return Objects.requireNonNull(editText.getText()).toString();
    }

    private void saveTaskDetails() {
        Duty duty = new Duty();
        duty.setId(0);
        duty.setTitle(getString(binding.edTaskTitle));
        duty.setDescription(getString(binding.edTaskDescription));
        duty.setTime(getString(binding.edTaskTime));
        duty.setDate(getString(binding.edTaskDate));
        duty.setNature(getString(binding.spinnerTaskNature));
        duty.setPriority(getString(binding.spinnerTaskPriority));
        duty.setRemindBeforeTime(getString(binding.spinnerRemindBefore));
        if (binding.btnSave.getText().equals("Save")) {
            String result = dutyRepository.insertTask(duty);
            if (result.equals("Duty Added Successfully")) {
                int Random = new Random().nextInt();
                setAlarm(calendar, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), Random, duty);
            } else {
                showToast(result);
            }
        } else {
            duty.setId(dutyIntent.getId());
            String result = dutyRepository.updateTask(duty);

            if (result.equals("Duty Updated Successfully")) {
                int Random = new Random().nextInt();
                setAlarm(calendar, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), Random, duty);

            } else {
                showToast(result);
            }

        }
    }

    private boolean validation() {
        if (isEmpty(binding.edTaskTitle, "Enter Task Title") ||
                isEmpty(binding.edTaskDescription, "Enter Task Description") ||
                isEmpty(binding.edTaskTime, "Enter Task Time") ||
                isEmpty(binding.edTaskDate, "Enter Task Date")) {
            return false;
        } else {
            return true;
        }
    }

    private boolean isEmpty(TextInputEditText editText, String message) {
        if (Objects.requireNonNull(editText.getText()).toString().isEmpty()) {
            showToast(message);
            return true;
        }
        return false;
    }

    @Override
    public void onBackPressed() {
        moveToHome();
        super.onBackPressed();
    }

    private void moveToHome() {
        Intent intent = new Intent(NotificationActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


    // Helper method to convert remindBeforeTime from spinner to minutes
    private int getRemindBeforeMinutes(String remindBeforeTime) {
        try {
            // Extract the numeric part from the spinner text
            String numericPart = remindBeforeTime.replaceAll("[^0-9]", "");
            return Integer.parseInt(numericPart);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return 0; // Default to 0 minutes if parsing fails
        }
    }

    private void requestRuntimePermissions() {
        if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            println("Notification permission not granted");
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.RECEIVE_BOOT_COMPLETED,
                            Manifest.permission.POST_NOTIFICATIONS
                    },
                    PERMISSION_REQUEST_CODE
            );
        } else {
            createNotificationChannel();
            showDateTimePicker();
        }
    }

    private void showDateTimePicker() {
        calendar = Calendar.getInstance();

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (DatePicker datePicker, int year, int month, int dayOfMonth) -> {
                    calendar.set(Calendar.YEAR, year);
                    calendar.set(Calendar.MONTH, month);
                    calendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                    updateDate(calendar.getTime());
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );

        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis() - 1000);
        datePickerDialog.show();
    }

    private void showTimePicker(Calendar calendar) {
        new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    calendar.set(Calendar.MINUTE, minute);
                    updateTime();
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
        ).show();
    }

    private void setAlarm(Calendar calendar, int hourOfDay, int minute, int random, Duty duty) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra(EXTRA_TASK_TITLE, duty.getTitle());
        intent.putExtra(EXTRA_TASK_TITLE, duty.getTitle());
        intent.putExtra(TASK_TIME, duty.getTime());
        intent.putExtra(TASK_DATE, duty.getDate());
        intent.putExtra(EXTRA_TASK_DESCRIPTION, duty.getDescription());
        intent.putExtra(TASK_NATURE_DESCRIPTION, duty.getNature());
        intent.putExtra(TASK_PRIORITY, duty.getPriority());
        intent.putExtra(TASK_REMIND_BEFORE_TIME, duty.getRemindBeforeTime());
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                random,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
        );

        calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
        String remindBefore = binding.spinnerRemindBefore.getSelectedItem().toString();
        switch (remindBefore) {
            case "5 Minutes":
                calendar.set(Calendar.MINUTE, minute - 5);
                break;
            case "10 Minutes":
                calendar.set(Calendar.MINUTE, minute - 10);
                break;
            case "15 Minutes":
                calendar.set(Calendar.MINUTE, minute - 15);
                break;
        }

        calendar.set(Calendar.SECOND, 0);

        try {
            alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    pendingIntent
            );
            Log.d("Notification", "setExact: ");
            moveToHome();
        } catch (SecurityException e) {
            Log.d("Notification", "setAlarm: " + e.getMessage());
            alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    calendar.getTimeInMillis(),
                    pendingIntent
            );
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes audioAttributes= new AudioAttributes.Builder()
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .build();

            String name = "My Channel";
            String descriptionText = "Channel for my app";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(descriptionText);
            channel.enableLights(true);
            long[] pattern = {500,500,500,500,500,500,500,500,500};
            channel.setVibrationPattern(pattern);
            channel.enableVibration(true);
            Uri alarmSound = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            channel.setSound(alarmSound,audioAttributes);
            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private static void println(String message) {
        System.out.println(message);
    }

    public static final String CHANNEL_ID = "my_channel";
    public static final int ALARM_REQUEST_CODE = 123;
    public static final int PERMISSION_REQUEST_CODE = 456;

    public static class AlarmReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {


            showNotification(context, intent);
        }

        private static void showNotification(Context context, Intent intent) {
            String title = intent.getStringExtra(EXTRA_TASK_TITLE);
            String description = intent.getStringExtra(EXTRA_TASK_DESCRIPTION);
            String Nature = intent.getStringExtra(TASK_NATURE_DESCRIPTION);
            String Priority = intent.getStringExtra(TASK_PRIORITY);
            String Date = intent.getStringExtra(TASK_DATE);
            String Time = intent.getStringExtra(TASK_TIME);
            String RemindBefore = intent.getStringExtra(TASK_REMIND_BEFORE_TIME);
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            Uri alarmSound = Uri.parse("android.resource://" + context.getPackageName() + "/" + R.raw.raw);
            // Add a button for more details
            Intent detailsIntent = new Intent(context, ViewDutyDetail.class);
            detailsIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            Bundle bundle = new Bundle();
            bundle.putString(EXTRA_TASK_TITLE, title);
            bundle.putString(EXTRA_TASK_DESCRIPTION, description);
            bundle.putString(TASK_NATURE_DESCRIPTION, Nature);
            bundle.putString(TASK_TIME, Time);
            bundle.putString(TASK_DATE, Date);
            bundle.putString(TASK_PRIORITY, Priority);
            bundle.putString(TASK_REMIND_BEFORE_TIME, RemindBefore);

            detailsIntent.putExtras(bundle);

            PendingIntent detailsPendingIntent = PendingIntent.getActivity(
                    context,
                    0,
                    detailsIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT
            );

            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(context, CHANNEL_ID)
                        .setContentTitle(title)
                        .setContentText("This is reminder of " + Nature + " Which is going to take place in " + RemindBefore)
                        .setSmallIcon(R.drawable.ic_app_icon)
                        .setContentIntent(detailsPendingIntent)
                        .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE)
                        .setOnlyAlertOnce(true)
                        .setAutoCancel(true);
            } else {
                builder = new Notification.Builder(context)
                        .setContentTitle(title)
                        .setContentText("This is reminder of " + Nature + " Which is going to take place in " + RemindBefore)
                        .setSmallIcon(R.drawable.ic_app_icon)
                        .setContentIntent(detailsPendingIntent)
                        .setSound(alarmSound)
                        .setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE)
                        .setOnlyAlertOnce(true)
                        .setAutoCancel(true);
            }
            builder.addAction(R.drawable.baseline_preview_24, "More Details", detailsPendingIntent);
            notificationManager.notify((int) System.currentTimeMillis(), builder.build());
        }
    }
}
