package com.example.academate.ui.task;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.academate.database.DutyRepository;
import com.example.academate.databinding.ActivitySeeAllTaskBinding;
import com.example.academate.model.Duty;
import com.example.academate.ui.home.MainActivity;
import com.example.academate.ui.home.DutiesAdapter;
import com.example.academate.ui.home.NotificationActivity;

import java.util.ArrayList;
import java.util.List;

public class SeeAllDuties extends AppCompatActivity implements DutiesAdapter.DutyCallback {

    private ActivitySeeAllTaskBinding binding;
    private DutyRepository dutyRepository;
    private DutiesAdapter dutiesAdapter;
    private List<Duty> dataList = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivitySeeAllTaskBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dutyRepository = new DutyRepository(getApplicationContext());
        handleEventListeners();
        setAdapter();
        setupObserver();
    }
    private void setupObserver() {
        dutyRepository.getAllDuties().observe(this, new Observer<List<Duty>>() {
            @Override
            public void onChanged(List<Duty> duties) {
                // Update UI with the new data
                dataList.clear();
                dataList.addAll(duties);
                dutiesAdapter.notifyDataSetChanged();
            }
        });

    }
    private void setAdapter() {
        dutiesAdapter = new DutiesAdapter(dataList, this);
        binding.recyclerViewTask.setAdapter(dutiesAdapter);
        binding.recyclerViewTask.setLayoutManager(new LinearLayoutManager(SeeAllDuties.this, LinearLayoutManager.VERTICAL, false));
    }
    private void handleEventListeners() {
        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                moveToHome();
            }
        });
    }

    @Override
    public void onBackPressed() {
        moveToHome();
        super.onBackPressed();
    }

    private void moveToHome() {
        Intent intent= new Intent(SeeAllDuties.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }

    @Override
    public void onDeleteClick(Duty duty, Integer position) {
        dutyRepository.deleteTask(duty);
        dataList.remove(duty);
        dutiesAdapter.notifyItemRemoved(position);

    }

    @Override
    public void onEditClick(Duty duty, Integer position) {
        Intent intent = new Intent(SeeAllDuties.this, NotificationActivity.class);
        intent.putExtra("taskObject", duty);
        startActivity(intent);
    }

    @Override
    public void onSeeDetails(Duty duty) {}
}