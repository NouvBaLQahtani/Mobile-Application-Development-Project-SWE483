package com.example.academate.model;

public class DutyEvent {
    private String title;
    private String description;
    private String dateMillis; // Date in milliseconds

    public DutyEvent(String title, String description, String dateMillis) {
        this.title = title;
        this.description = description;
        this.dateMillis = dateMillis;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getDateMillis() {
        return dateMillis;
    }
}

