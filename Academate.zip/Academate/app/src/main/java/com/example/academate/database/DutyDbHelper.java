package com.example.academate.database;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DutyDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "tasks.db";
    private static final int DATABASE_VERSION = 1;

    // Define the table and column names
    public static final String TABLE_Duty= "tasks";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_TITLE = "title";
    public static final String COLUMN_DESCRIPTION = "description";
    public static final String COLUMN_TIME = "time";
    public static final String COLUMN_DATE = "date";
    public static final String COLUMN_NATURE = "nature";
    public static final String COLUMN_PRIORITY = "priority";
    public static final String COLUMN_REMIND_BEFORE_TIME = "remind_before_time";

    // SQL query to create the Dutytable
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_Duty+ " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_TITLE + " TEXT, " +
                    COLUMN_DESCRIPTION + " TEXT, " +
                    COLUMN_TIME + " TEXT, " +
                    COLUMN_DATE + " TEXT, " +
                    COLUMN_NATURE + " TEXT, " +
                    COLUMN_PRIORITY + " TEXT, " +
                    COLUMN_REMIND_BEFORE_TIME + " TEXT" +
                    ")";

    public DutyDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Handle upgrades, if needed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Duty);
        onCreate(db);
    }
}

