package com.example.academate.ui.home;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.Manifest;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;

import com.example.academate.database.DutyRepository;
import com.example.academate.databinding.ActivityMainBinding;
import com.example.academate.model.Duty;
import com.example.academate.ui.task.SeeAllDuties;
import com.example.academate.ui.task.ViewDutyDetail;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements DutiesAdapter.DutyCallback {
    private ActivityMainBinding binding;
    private DutyRepository dutyRepository;
    private static final int NOTIFICATION_PERMISSION_REQUEST_CODE = 1001;
    private DutiesAdapter dutiesAdapter;
    private final List<Duty> dataList = new ArrayList<>();
    public static final String EXTRA_TASK_TITLE = "extra_task_title";
    public static final String EXTRA_TASK_DESCRIPTION = "extra_task_description";
    public static final String TASK_NATURE_DESCRIPTION = "extra_task_nature";
    public static final String TASK_PRIORITY = "extra_task_priority";

    public static final String TASK_DATE = "extra_task_date";

    public static final String TASK_TIME = "extra_task_time";

    public static final String TASK_REMIND_BEFORE_TIME = "extra_task_remind_before";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dutyRepository = new DutyRepository(getApplicationContext());
        handleEventListeners();
        setAdapter();
        setupObserver();
        if (!checkNotificationPermission()) {
            // Permission not granted, request it
            requestNotificationPermission();
        }
    }

    private void setupObserver() {
        dutyRepository.getUpcomingDuties().observe(this, new Observer<List<Duty>>() {
            @Override
            public void onChanged(List<Duty> duties) {
                // Update UI with the new data
                dataList.clear();
                dataList.addAll(duties);
                dutiesAdapter.notifyDataSetChanged();
            }
        });

    }

    @Override
    protected void onResume() {
        if (!checkNotificationPermission()) {
            // Permission not granted, request it
            requestNotificationPermission();
        }

        super.onResume();

    }



    private void setAdapter() {
        dutiesAdapter = new DutiesAdapter(dataList, this);
        binding.recyclerViewTask.setAdapter(dutiesAdapter);
        binding.recyclerViewTask.setLayoutManager(new LinearLayoutManager(MainActivity.this, LinearLayoutManager.VERTICAL, false));
    }

    private boolean checkNotificationPermission() {
        // Check if the permission has been granted
        return ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestNotificationPermission() {
        // Request the permission
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            // Check if the permission request was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, handle it
                // Your code here
            } else {
                // Permission denied
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    if (!shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                        // User selected "Never ask again"
                        showSettingsDialog();
                    } else {
                        // Show an explanation and request the permission again
                        requestNotificationPermission();
                        Toast.makeText(this, "Notification permission is required for this feature.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
    }

    private void showSettingsDialog() {
        Toast.makeText(this, "Please enable notification permissions in the app settings.", Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivityForResult(intent, NOTIFICATION_PERMISSION_REQUEST_CODE);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == NOTIFICATION_PERMISSION_REQUEST_CODE) {
            // Check if the user has granted the required permission in the settings
            if (!checkNotificationPermission()) {
                requestNotificationPermission();
                // Permission still not granted
                Toast.makeText(this, "Notification permission is required for this feature.", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void handleEventListeners() {


        binding.btnAddNewDuty.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, NotificationActivity.class));
            }
        });
        binding.tvCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CalendarActivity.class));
            }
        });

        binding.tvSeeAll.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, SeeAllDuties.class));
            }
        });
    }


    @Override
    public void onDeleteClick(Duty duty, Integer position) {
        showDeleteConfirmationDialog(this,duty,position);

    }

    @Override
    public void onEditClick(Duty duty, Integer position) {
        Intent intent = new Intent(MainActivity.this, NotificationActivity.class);
        intent.putExtra("taskObject", duty);
        startActivity(intent);
    }

    @Override
    public void onSeeDetails(Duty duty) {
        Intent intent = new Intent(MainActivity.this, ViewDutyDetail.class);
        //intent.putExtra("taskObject", duty);
        Bundle bundle = new Bundle();
        bundle.putString(EXTRA_TASK_TITLE, duty.getTitle());
        bundle.putString(EXTRA_TASK_DESCRIPTION, duty.getDescription());
        bundle.putString(TASK_NATURE_DESCRIPTION, duty.getNature());
        bundle.putString(TASK_TIME, duty.getTime());
        bundle.putString(TASK_DATE, duty.getDate());
        bundle.putString(TASK_PRIORITY, duty.getPriority());
        bundle.putString(TASK_REMIND_BEFORE_TIME, duty.getRemindBeforeTime());

        intent.putExtras(bundle);
        startActivity(intent);
    }

    private void showDeleteConfirmationDialog(Context context, Duty duty, Integer position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setMessage("Are you sure you want to delete?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dutyRepository.deleteTask(duty);
                        dataList.remove(duty);
                        dutiesAdapter.notifyItemRemoved(position);
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.dismiss();
                    }
                });

        // Create and show the AlertDialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }
}