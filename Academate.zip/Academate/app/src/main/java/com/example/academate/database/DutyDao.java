package com.example.academate.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.academate.model.Duty;

import java.util.ArrayList;
import java.util.List;

public class DutyDao {
    private final DutyDbHelper dbHelper;

    public DutyDao(DutyDbHelper dbHelper) {
        this.dbHelper = dbHelper;
    }

    public void insert(Duty duty) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // Insert the task into the "tasks" table
        // You should handle exceptions and close the database properly in a production app
        // For simplicity, exceptions are not handled here
        db.insert(DutyDbHelper.TABLE_Duty, null, dutyToContentValues(duty));
        db.close();

    }
     boolean isDuplicateDateTime(Duty newDuty) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        // Define the columns you want to check for duplicates
        String[] projection = {
                DutyDbHelper.COLUMN_DATE,
                DutyDbHelper.COLUMN_TIME
        };

        // Define the selection criteria
        String selection = DutyDbHelper.COLUMN_DATE + " = ? AND " +
                DutyDbHelper.COLUMN_TIME + " = ?";

        // Define the selection arguments
        String[] selectionArgs = {
                newDuty.getDate(),
                newDuty.getTime()
        };

        // Query the database to check if the same date and time combination already exists
        Cursor cursor = db.query(
                DutyDbHelper.TABLE_Duty,  // Table name
                projection,              // Columns to check
                selection,               // WHERE clause
                selectionArgs,           // Values for the WHERE clause
                null,                    // Don't group the rows
                null,                    // Don't filter by row groups
                null                     // Don't sort the order
        );

        // If the cursor has any rows, a record with the same date and time already exists
        boolean isDuplicate = cursor.getCount() > 0;

        // Close the cursor and database
        cursor.close();
        db.close();

        return isDuplicate;
    }

    public void update(Duty duty) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // Update the task in the "tasks" table
        // You should handle exceptions and close the database properly in a production app
        // For simplicity, exceptions are not handled here
        db.update(DutyDbHelper.TABLE_Duty, dutyToContentValues(duty),
                DutyDbHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(duty.getId())});
        db.close();
    }

    public void delete(Duty duty) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        // Delete the task from the "tasks" table
        // You should handle exceptions and close the database properly in a production app
        // For simplicity, exceptions are not handled here
        db.delete(DutyDbHelper.TABLE_Duty,
                DutyDbHelper.COLUMN_ID + " = ?", new String[]{String.valueOf(duty.getId())});
        db.close();
    }

    public LiveData<List<Duty>> getAllDuties() {
        MutableLiveData<List<Duty>> liveData = new MutableLiveData<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        // Query all tasks from the "tasks" table
        Cursor cursor = db.query(DutyDbHelper.TABLE_Duty, null, null, null, null, null, null);

        List<Duty> duties = new ArrayList<>();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                duties.add(cursorToTask(cursor));
            }
            cursor.close();
        }

        liveData.setValue(duties);
        db.close();
        return liveData;
    }

    public LiveData<List<Duty>> getUpcomingDuties() {
        MutableLiveData<List<Duty>> liveData = new MutableLiveData<>();
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        // Query upcoming tasks from the "tasks" table
        Cursor cursor = db.query(DutyDbHelper.TABLE_Duty, null,
                DutyDbHelper.COLUMN_DATE + " >= date('now')", null, null, null,
                DutyDbHelper.COLUMN_DATE + " ASC");

        List<Duty> duties = new ArrayList<>();
        if (cursor != null) {
            while (cursor.moveToNext()) {
                duties.add(cursorToTask(cursor));
            }
            cursor.close();
        }

        liveData.setValue(duties);
        db.close();
        return liveData;
    }

    // Helper methods to convert between Task objects and ContentValues/Cursor

    private ContentValues dutyToContentValues(Duty duty) {
        ContentValues values = new ContentValues();
        values.put(DutyDbHelper.COLUMN_TITLE, duty.getTitle());
        values.put(DutyDbHelper.COLUMN_DESCRIPTION, duty.getDescription());
        values.put(DutyDbHelper.COLUMN_TIME, duty.getTime());
        values.put(DutyDbHelper.COLUMN_DATE, duty.getDate());
        values.put(DutyDbHelper.COLUMN_NATURE, duty.getNature());
        values.put(DutyDbHelper.COLUMN_PRIORITY, duty.getPriority());
        values.put(DutyDbHelper.COLUMN_REMIND_BEFORE_TIME, duty.getRemindBeforeTime());
        return values;
    }

    @SuppressLint("Range")
    private Duty cursorToTask(Cursor cursor) {
        Duty duty = new Duty();
        duty.setId(cursor.getInt(cursor.getColumnIndex(DutyDbHelper.COLUMN_ID)));
        duty.setTitle(cursor.getString(cursor.getColumnIndex(DutyDbHelper.COLUMN_TITLE)));
        duty.setDescription(cursor.getString(cursor.getColumnIndex(DutyDbHelper.COLUMN_DESCRIPTION)));
        duty.setTime(cursor.getString(cursor.getColumnIndex(DutyDbHelper.COLUMN_TIME)));
        duty.setDate(cursor.getString(cursor.getColumnIndex(DutyDbHelper.COLUMN_DATE)));
        duty.setNature(cursor.getString(cursor.getColumnIndex(DutyDbHelper.COLUMN_NATURE)));
        duty.setPriority(cursor.getString(cursor.getColumnIndex(DutyDbHelper.COLUMN_PRIORITY)));
        duty.setRemindBeforeTime(cursor.getString(cursor.getColumnIndex(DutyDbHelper.COLUMN_REMIND_BEFORE_TIME)));
        return duty;
    }
}


