package com.example.academate.ui.home;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.academate.databinding.TaskItemBinding;
import com.example.academate.model.Duty;

import java.util.List;

public class DutiesAdapter extends RecyclerView.Adapter<DutiesAdapter.TaskViewHolder> {

    private final DutyCallback dutyCallback;
    private List<Duty> dutyList;

    public interface DutyCallback {
        void onDeleteClick(Duty duty, Integer position);
        void onEditClick(Duty duty, Integer position);
        void onSeeDetails(Duty duty);
    }
    public DutiesAdapter(List<Duty> dutyList, DutyCallback dutyCallback) {
        this.dutyList = dutyList;
        this.dutyCallback = dutyCallback;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        TaskItemBinding binding = TaskItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new TaskViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Duty duty = dutyList.get(position);
        holder.bind(duty, dutyCallback);
    }

    @Override
    public int getItemCount() {
        return dutyList.size();
    }

    static class TaskViewHolder extends RecyclerView.ViewHolder {

        private TaskItemBinding binding;

        TaskViewHolder(TaskItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(Duty duty, DutyCallback dutyCallback) {
            binding.tvTaskName.setText(duty.getTitle());
            binding.tvTaskDescription.setText(duty.getDescription());
            binding.tvTaskDate.setText(duty.getDate());
            binding.tvTaskTime.setText(duty.getTime());

            binding.tvSeeDetails.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dutyCallback.onSeeDetails(duty);
                }
            });

            binding.deleteTask.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dutyCallback.onDeleteClick(duty,getAdapterPosition());
                }
            });

            binding.editTask.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    dutyCallback.onEditClick(duty,getAdapterPosition());
                }
            });
        }


    }
}

