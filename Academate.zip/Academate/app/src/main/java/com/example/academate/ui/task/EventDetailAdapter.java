package com.example.academate.ui.task;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.academate.databinding.EventContentItemBinding;
import com.example.academate.databinding.TaskItemBinding;
import com.example.academate.model.Duty;
import com.example.academate.utils.EventObjects;

import java.util.EventObject;
import java.util.List;

public class EventDetailAdapter extends RecyclerView.Adapter<EventDetailAdapter.EventViewHolder> {

    private List<EventObjects> eventObjectsList;


    public EventDetailAdapter(List<EventObjects> eventObjects) {
        this.eventObjectsList = eventObjects;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        EventContentItemBinding binding = EventContentItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new EventViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        EventObjects duty = eventObjectsList.get(position);
        holder.bind(duty);
    }

    @Override
    public int getItemCount() {
        return eventObjectsList.size();
    }

    static class EventViewHolder extends RecyclerView.ViewHolder {

        private EventContentItemBinding binding;

        EventViewHolder(EventContentItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(EventObjects eventObjects) {
            binding.tvEventName.setText(eventObjects.getMessage());

        }


    }
}

