package com.example.academate.ui.task;


import static com.example.academate.ui.home.NotificationActivity.EXTRA_TASK_DESCRIPTION;
import static com.example.academate.ui.home.NotificationActivity.EXTRA_TASK_TITLE;
import static com.example.academate.ui.home.NotificationActivity.TASK_DATE;
import static com.example.academate.ui.home.NotificationActivity.TASK_NATURE_DESCRIPTION;
import static com.example.academate.ui.home.NotificationActivity.TASK_PRIORITY;
import static com.example.academate.ui.home.NotificationActivity.TASK_REMIND_BEFORE_TIME;
import static com.example.academate.ui.home.NotificationActivity.TASK_TIME;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.academate.databinding.ActivityViewDutyDetailBinding;
import com.example.academate.ui.home.MainActivity;

public class ViewDutyDetail extends AppCompatActivity {

    private ActivityViewDutyDetailBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityViewDutyDetailBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveToHome();
            }
        });
        receiveData();

    }

    @Override
    public void onBackPressed() {
        moveToHome();
        super.onBackPressed();
    }

    private void receiveData() {
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String title = extras.getString(EXTRA_TASK_TITLE);
            String description = extras.getString(EXTRA_TASK_DESCRIPTION);
            String Nature = extras.getString(TASK_NATURE_DESCRIPTION);
            String Priority = extras.getString(TASK_PRIORITY);
            String Date = extras.getString(TASK_DATE);
            String Time = extras.getString(TASK_TIME);
            String RemindBefore = extras.getString(TASK_REMIND_BEFORE_TIME);
            binding.edTaskTitle.setText(title);
            binding.edTaskDescription.setText(description);
            binding.edTaskDate.setText(Date);
            binding.edTaskTime.setText(Time);
            binding.remindBefore.setText("Remind Before: " + RemindBefore);
            binding.natureOfDuty.setText("Nature of Duty: " + Nature);
            binding.priorityOfDuty.setText("Priority of Duty: " + Priority);
        } else {
            Log.d("Nutre:", "receiveData: Null Ha yeh");

        }
    }

    private void moveToHome() {
        Intent intent = new Intent(ViewDutyDetail.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }
}