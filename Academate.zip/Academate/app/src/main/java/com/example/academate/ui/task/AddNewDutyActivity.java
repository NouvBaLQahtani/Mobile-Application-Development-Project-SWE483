package com.example.academate.ui.task;

import android.Manifest;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationManagerCompat;

import com.example.academate.R;
import com.example.academate.database.DutyRepository;
import com.example.academate.databinding.ActivityAddNewTaskBinding;
import com.example.academate.model.Duty;
import com.example.academate.ui.home.MainActivity;
import com.google.android.material.textfield.TextInputEditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.Random;

public class AddNewDutyActivity extends AppCompatActivity {

    private ActivityAddNewTaskBinding binding;
    private DutyRepository dutyRepository;
    private Calendar calendar;
    private AlarmManager alarmManager;
    private PendingIntent pendingIntent;
    public static final String EXTRA_ALARM_TIME = "extra_alarm_time";
    public static final String EXTRA_TASK_TITLE = "extra_task_title";
    public static final String EXTRA_TASK_DESCRIPTION = "extra_task_description";
    public static final String TASK_NATURE_DESCRIPTION = "extra_task_nature";
    public static final String TASK_PRIORITY = "extra_task_priority";
    public static final String TASK_DATE = "extra_task_date";
    public static final String EXTRA_TASK_ID = "extra_task_id";
    public static final String TASK_TIME = "extra_task_time";
    public static final String TASK_REMIND_BEFORE_TIME = "extra_task_remind_before";

    private int selectedHour = 0;
    private int selectedMinute = 0;
    private Duty dutyIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityAddNewTaskBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        dutyRepository = new DutyRepository(getApplicationContext());
        calendar = Calendar.getInstance();
        setupEventListeners();
        receiveData();
    }

    private void receiveData() {
        Intent intent = getIntent();
        if (intent.hasExtra("taskObject")) {
            dutyIntent = (Duty) intent.getSerializableExtra("taskObject");
            binding.edTaskTitle.setText(dutyIntent.getTitle());
            binding.edTaskDescription.setText(dutyIntent.getDescription());
            binding.edTaskDate.setText(dutyIntent.getDate());
            binding.edTaskTime.setText(dutyIntent.getTime());
            binding.btnSave.setText(R.string.confirm);
        }
    }

    private void setupEventListeners() {
        binding.btnSave.setOnClickListener(v -> {
            if (validation()) {
                saveTaskDetails();
            }
        });



        binding.edTaskDate.setOnClickListener(v -> showDatePickerDialog());

        binding.edTaskTime.setOnClickListener(v -> showTimePickerDialog());

        binding.ivBack.setOnClickListener(view -> moveToHome());

    }

    private void saveTaskDetails() {
        Duty duty = new Duty();
        duty.setId(0);
        duty.setTitle(getString(binding.edTaskTitle));
        duty.setDescription(getString(binding.edTaskDescription));
        duty.setTime(getString(binding.edTaskTime));
        duty.setDate(getString(binding.edTaskDate));
        duty.setNature(getString(binding.spinnerTaskNature));
        duty.setPriority(getString(binding.spinnerTaskPriority));
        duty.setRemindBeforeTime(getString(binding.spinnerRemindBefore));
        if (binding.btnSave.getText().equals("Save")) {
            String result = dutyRepository.insertTask(duty);
            if (result.equals("Duty Added Successfully")) {
                requestRuntimePermissions(new Random().nextInt(),duty);
            } else {
                showToast(result);
            }
        } else {
            duty.setId(dutyIntent.getId());
            String result = dutyRepository.updateTask(duty);

            if (result.equals("Duty Updated Successfully")) {
                requestRuntimePermissions(new Random().nextInt(),duty);
            } else {
                showToast(result);
            }

        }
    }

    private boolean validation() {
        if (isEmpty(binding.edTaskTitle, "Enter Duty Title") ||
                isEmpty(binding.edTaskDescription, "Enter Duty Description") ||
                isEmpty(binding.edTaskTime, "Select Duty Time") ||
                isEmpty(binding.edTaskDate, "Select Duty Date")) {
            return false;
        } else {
            return true;
        }
    }

    private boolean isEmpty(TextInputEditText editText, String message) {
        if (Objects.requireNonNull(editText.getText()).toString().isEmpty()) {
            showToast(message);
            return true;
        }
        return false;
    }

    private void showDatePickerDialog() {
        new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    calendar.set(year, month, dayOfMonth);
                    updateDate();
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        ).show();
    }

    private void updateDate() {
        String dateFormat = "YYYY-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(dateFormat, Locale.US);
        binding.edTaskDate.setText(sdf.format(calendar.getTime()));
    }

    private void showTimePickerDialog() {
        new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    calendar.set(Calendar.MINUTE, minute);
                    updateTime();
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
        ).show();
    }

    private void updateTime() {
        SimpleDateFormat timeFormat = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        binding.edTaskTime.setText(timeFormat.format(calendar.getTime()));
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private String getString(Spinner editText) {
        return Objects.requireNonNull(editText.getSelectedItem()).toString();
    }

    private String getString(TextInputEditText editText) {
        return Objects.requireNonNull(editText.getText()).toString();
    }

/*    private void scheduleAlarm(Duty duty) {
        SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.US);

        try {
            Date dateTime = dateTimeFormat.parse(duty.getDate() + " " + duty.getTime());

            int remindBeforeMinutes = getRemindBeforeMinutes(duty.getRemindBeforeTime());

            long alarmTimeMillis = dateTime.getTime() - (remindBeforeMinutes * 60 * 1000);

            // Pass task details to the service
            startMyService(alarmTimeMillis, duty);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }*/

    private void requestRuntimePermissions(int random,Duty duty) {
        if (!NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.RECEIVE_BOOT_COMPLETED,
                            Manifest.permission.POST_NOTIFICATIONS
                    },
                    PERMISSION_REQUEST_CODE
            );
        } else {
            try {
                SimpleDateFormat dateTimeFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.US);

                Date dateTime = dateTimeFormat.parse(duty.getDate() + " " + duty.getTime());

                int remindBeforeMinutes = getRemindBeforeMinutes(duty.getRemindBeforeTime());

                long alarmTimeMillis = dateTime.getTime() - (remindBeforeMinutes * 60 * 1000);

                createNotificationChannel();
                setAlarm(alarmTimeMillis,random,duty);

            } catch (ParseException e) {
                e.printStackTrace();
            }

        }
    }
    private void setAlarm(long alarmTimeMillis, int random,Duty duty) {
        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("taskObject", duty);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                random,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT
        );

        try {
            alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    alarmTimeMillis,
                    pendingIntent
            );
        } catch (SecurityException e) {
            alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    alarmTimeMillis,
                    pendingIntent
            );
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            String name = "My Channel";
            String descriptionText = "Channel for my app";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
            channel.setDescription(descriptionText);
            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(channel);
        }
    }
/*    private void startMyService(long alarmTime, Duty duty) {
        alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

        Intent intent = new Intent(AddNewDutyActivity.this, AlarmReceiver.class);

        // Use a unique requestCode for each alarm, for example, the duty ID
        int uniqueRequestCode = duty.getId(); // Assuming duty.getId() returns a unique identifier
        intent.putExtra(EXTRA_ALARM_TIME, alarmTime);
        intent.putExtra(EXTRA_TASK_ID, uniqueRequestCode);
        intent.putExtra(EXTRA_TASK_TITLE, duty.getTitle());
        intent.putExtra(EXTRA_TASK_DESCRIPTION, duty.getDescription());
        intent.putExtra(TASK_NATURE_DESCRIPTION, duty.getNature());
        intent.putExtra(TASK_TIME, duty.getTime());
        intent.putExtra(TASK_REMIND_BEFORE_TIME, duty.getRemindBeforeTime());
        pendingIntent = PendingIntent.getBroadcast(
                this,
                uniqueRequestCode,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT // Use FLAG_UPDATE_CURRENT to update the existing PendingIntent
        );

        alarmManager.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP, alarmTime, pendingIntent);

        showToast("Duty Added Successfully");
        moveToHome();
    }*/


    @Override
    public void onBackPressed() {
        moveToHome();
        super.onBackPressed();
    }

    private void moveToHome() {
        Intent intent = new Intent(AddNewDutyActivity.this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
    }


    // Helper method to convert remindBeforeTime from spinner to minutes
    private int getRemindBeforeMinutes(String remindBeforeTime) {
        try {
            // Extract the numeric part from the spinner text
            String numericPart = remindBeforeTime.replaceAll("[^0-9]", "");
            return Integer.parseInt(numericPart);
        } catch (NumberFormatException e) {
            e.printStackTrace();
            return 0; // Default to 0 minutes if parsing fails
        }
    }
    public static final String CHANNEL_ID = "my_channel";
    public static final int ALARM_REQUEST_CODE = 123;
    public static final int PERMISSION_REQUEST_CODE = 456;

    public static class AlarmReceiver extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.hasExtra("taskObject")) {
                showNotification(context,(Duty) intent.getSerializableExtra("taskObject"));
            }

        }

        private static void showNotification(Context context, Duty duty) {
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            Intent notificationIntent = new Intent(context, AddNewDutyActivity.class);
            PendingIntent pendingIntent = PendingIntent.getActivity(
                    context,
                    ALARM_REQUEST_CODE,
                    notificationIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT
            );

            Notification.Builder builder;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                builder = new Notification.Builder(context, CHANNEL_ID)
                        .setContentTitle(duty.getTitle())
                        .setContentText("This is simple reminder for duty "+duty.getNature() +" which is coming up next in "+ duty.getRemindBeforeTime())
                        .setSmallIcon(R.drawable.ic_app_icon)
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true);
            } else {
                builder = new Notification.Builder(context)
                        .setContentTitle(duty.getTitle())
                        .setContentText("This is simple reminder for duty "+duty.getNature() +" which is coming up next in "+ duty.getRemindBeforeTime())
                        .setSmallIcon(R.drawable.ic_app_icon)
                        .setContentIntent(pendingIntent)
                        .setAutoCancel(true);
            }

            notificationManager.notify((int) System.currentTimeMillis(), builder.build());
        }
    }

}
